package com.touchnav.app;

import android.content.Context;
import android.content.SharedPreferences;

public class AppPrefs {
    private static final String PREFS_NAME = "touchnav_prefs";

    // Gesture action keys
    public static final String KEY_SWIPE_RIGHT = "gesture_swipe_right";
    public static final String KEY_SWIPE_LEFT  = "gesture_swipe_left";
    public static final String KEY_SWIPE_UP    = "gesture_swipe_up";
    public static final String KEY_SWIPE_DOWN  = "gesture_swipe_down";
    public static final String KEY_SINGLE_TAP  = "gesture_single_tap";
    public static final String KEY_DOUBLE_TAP  = "gesture_double_tap";

    // UI keys
    public static final String KEY_OPACITY      = "button_opacity";
    public static final String KEY_SIZE         = "button_size";
    public static final String KEY_LOCK_POS     = "lock_position";
    public static final String KEY_VIBRATION    = "vibration";
    public static final String KEY_POS_X        = "pos_x";
    public static final String KEY_POS_Y        = "pos_y";
    public static final String KEY_SERVICE_RUNNING = "service_running";

    // Action constants
    public static final String ACTION_BACK           = "BACK";
    public static final String ACTION_HOME           = "HOME";
    public static final String ACTION_RECENTS        = "RECENTS";
    public static final String ACTION_FORWARD        = "FORWARD";
    public static final String ACTION_NOTIFICATIONS  = "NOTIFICATIONS";
    public static final String ACTION_POWER_MENU     = "POWER_MENU";
    public static final String ACTION_NOTHING        = "NOTHING";

    public static final String[] ACTION_LABELS = {
        "Geri", "Ana Ekran", "Son Uygulamalar",
        "İleri", "Bildirimler", "Güç Menüsü", "Hiçbir şey"
    };
    public static final String[] ACTION_VALUES = {
        ACTION_BACK, ACTION_HOME, ACTION_RECENTS,
        ACTION_FORWARD, ACTION_NOTIFICATIONS, ACTION_POWER_MENU, ACTION_NOTHING
    };

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static String getGesture(Context ctx, String key) {
        String def = ACTION_NOTHING;
        if (KEY_SWIPE_RIGHT.equals(key)) def = ACTION_BACK;
        else if (KEY_SWIPE_LEFT.equals(key)) def = ACTION_FORWARD;
        else if (KEY_SWIPE_UP.equals(key)) def = ACTION_HOME;
        else if (KEY_SWIPE_DOWN.equals(key)) def = ACTION_RECENTS;
        else if (KEY_DOUBLE_TAP.equals(key)) def = ACTION_RECENTS;
        else if (KEY_SINGLE_TAP.equals(key)) def = ACTION_NOTIFICATIONS;
        return prefs(ctx).getString(key, def);
    }

    public static void setGesture(Context ctx, String key, String value) {
        prefs(ctx).edit().putString(key, value).apply();
    }

    public static int getOpacity(Context ctx) {
        return prefs(ctx).getInt(KEY_OPACITY, 55);
    }
    public static void setOpacity(Context ctx, int v) {
        prefs(ctx).edit().putInt(KEY_OPACITY, v).apply();
    }

    public static int getSize(Context ctx) {
        return prefs(ctx).getInt(KEY_SIZE, 50);
    }
    public static void setSize(Context ctx, int v) {
        prefs(ctx).edit().putInt(KEY_SIZE, v).apply();
    }

    public static boolean isLockPosition(Context ctx) {
        return prefs(ctx).getBoolean(KEY_LOCK_POS, false);
    }
    public static void setLockPosition(Context ctx, boolean v) {
        prefs(ctx).edit().putBoolean(KEY_LOCK_POS, v).apply();
    }

    public static boolean isVibration(Context ctx) {
        return prefs(ctx).getBoolean(KEY_VIBRATION, true);
    }
    public static void setVibration(Context ctx, boolean v) {
        prefs(ctx).edit().putBoolean(KEY_VIBRATION, v).apply();
    }

    public static int getPosX(Context ctx) {
        return prefs(ctx).getInt(KEY_POS_X, 50);
    }
    public static int getPosY(Context ctx) {
        return prefs(ctx).getInt(KEY_POS_Y, 300);
    }
    public static void setPos(Context ctx, int x, int y) {
        prefs(ctx).edit().putInt(KEY_POS_X, x).putInt(KEY_POS_Y, y).apply();
    }

    public static boolean isServiceRunning(Context ctx) {
        return prefs(ctx).getBoolean(KEY_SERVICE_RUNNING, false);
    }
    public static void setServiceRunning(Context ctx, boolean v) {
        prefs(ctx).edit().putBoolean(KEY_SERVICE_RUNNING, v).apply();
    }

    public static int getActionIndex(String actionValue) {
        for (int i = 0; i < ACTION_VALUES.length; i++) {
            if (ACTION_VALUES[i].equals(actionValue)) return i;
        }
        return 0;
    }
}
