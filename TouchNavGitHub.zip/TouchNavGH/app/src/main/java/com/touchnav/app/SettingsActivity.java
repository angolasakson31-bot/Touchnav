package com.touchnav.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private Spinner spSwipeRight, spSwipeLeft, spSwipeUp, spSwipeDown,
                    spSingleTap, spDoubleTap;
    private SeekBar sbOpacity, sbSize;
    private TextView tvOpacity, tvSize;
    private Switch swLock, swVibration;
    private Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Gesture Ayarları");
        }

        spSwipeRight = findViewById(R.id.spinner_swipe_right);
        spSwipeLeft  = findViewById(R.id.spinner_swipe_left);
        spSwipeUp    = findViewById(R.id.spinner_swipe_up);
        spSwipeDown  = findViewById(R.id.spinner_swipe_down);
        spSingleTap  = findViewById(R.id.spinner_single_tap);
        spDoubleTap  = findViewById(R.id.spinner_double_tap);
        sbOpacity    = findViewById(R.id.seekbar_opacity);
        sbSize       = findViewById(R.id.seekbar_size);
        tvOpacity    = findViewById(R.id.tv_opacity_value);
        tvSize       = findViewById(R.id.tv_size_value);
        swLock       = findViewById(R.id.switch_lock_position);
        swVibration  = findViewById(R.id.switch_vibration);
        btnSave      = findViewById(R.id.btn_save_settings);

        // Setup spinners
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, AppPrefs.ACTION_LABELS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spSwipeRight.setAdapter(adapter);
        spSwipeLeft.setAdapter(adapter);
        spSwipeUp.setAdapter(adapter);
        spSwipeDown.setAdapter(adapter);
        spSingleTap.setAdapter(adapter);
        spDoubleTap.setAdapter(adapter);

        // Load saved values
        spSwipeRight.setSelection(AppPrefs.getActionIndex(AppPrefs.getGesture(this, AppPrefs.KEY_SWIPE_RIGHT)));
        spSwipeLeft.setSelection(AppPrefs.getActionIndex(AppPrefs.getGesture(this, AppPrefs.KEY_SWIPE_LEFT)));
        spSwipeUp.setSelection(AppPrefs.getActionIndex(AppPrefs.getGesture(this, AppPrefs.KEY_SWIPE_UP)));
        spSwipeDown.setSelection(AppPrefs.getActionIndex(AppPrefs.getGesture(this, AppPrefs.KEY_SWIPE_DOWN)));
        spSingleTap.setSelection(AppPrefs.getActionIndex(AppPrefs.getGesture(this, AppPrefs.KEY_SINGLE_TAP)));
        spDoubleTap.setSelection(AppPrefs.getActionIndex(AppPrefs.getGesture(this, AppPrefs.KEY_DOUBLE_TAP)));

        sbOpacity.setProgress(AppPrefs.getOpacity(this));
        sbSize.setProgress(AppPrefs.getSize(this));
        swLock.setChecked(AppPrefs.isLockPosition(this));
        swVibration.setChecked(AppPrefs.isVibration(this));

        updateLabels();

        sbOpacity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                tvOpacity.setText(p + "%");
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        sbSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int p, boolean u) {
                int dp = 40 + (int)(p * 0.5f);
                tvSize.setText(dp + "dp");
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        btnSave.setOnClickListener(v -> saveSettings());
    }

    private void updateLabels() {
        tvOpacity.setText(AppPrefs.getOpacity(this) + "%");
        int dp = 40 + (int)(AppPrefs.getSize(this) * 0.5f);
        tvSize.setText(dp + "dp");
    }

    private void saveSettings() {
        AppPrefs.setGesture(this, AppPrefs.KEY_SWIPE_RIGHT,
                AppPrefs.ACTION_VALUES[spSwipeRight.getSelectedItemPosition()]);
        AppPrefs.setGesture(this, AppPrefs.KEY_SWIPE_LEFT,
                AppPrefs.ACTION_VALUES[spSwipeLeft.getSelectedItemPosition()]);
        AppPrefs.setGesture(this, AppPrefs.KEY_SWIPE_UP,
                AppPrefs.ACTION_VALUES[spSwipeUp.getSelectedItemPosition()]);
        AppPrefs.setGesture(this, AppPrefs.KEY_SWIPE_DOWN,
                AppPrefs.ACTION_VALUES[spSwipeDown.getSelectedItemPosition()]);
        AppPrefs.setGesture(this, AppPrefs.KEY_SINGLE_TAP,
                AppPrefs.ACTION_VALUES[spSingleTap.getSelectedItemPosition()]);
        AppPrefs.setGesture(this, AppPrefs.KEY_DOUBLE_TAP,
                AppPrefs.ACTION_VALUES[spDoubleTap.getSelectedItemPosition()]);

        AppPrefs.setOpacity(this, sbOpacity.getProgress());
        AppPrefs.setSize(this, sbSize.getProgress());
        AppPrefs.setLockPosition(this, swLock.isChecked());
        AppPrefs.setVibration(this, swVibration.isChecked());

        Toast.makeText(this, "✓ Ayarlar kaydedildi! Servisi yeniden başlatın.",
                Toast.LENGTH_SHORT).show();

        // Restart service if running to apply new settings
        if (AppPrefs.isServiceRunning(this)) {
            Intent serviceIntent = new Intent(this, FloatingButtonService.class);
            stopService(serviceIntent);
            startForegroundService(serviceIntent);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
