package com.touchnav.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import androidx.core.app.NotificationCompat;

public class FloatingButtonService extends Service {

    private static final String CHANNEL_ID = "touchnav_channel";
    private static final int NOTIF_ID = 1001;

    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private GestureDetector gestureDetector;
    private Vibrator vibrator;

    // For drag tracking
    private int initialX, initialY;
    private float initialTouchX, initialTouchY;
    private boolean isDragging = false;
    private static final int DRAG_THRESHOLD = 10; // px

    // Double tap tracking
    private long lastTapTime = 0;
    private static final long DOUBLE_TAP_WINDOW = 350; // ms

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());

        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_button, null);

        int buttonSizeDp = getButtonSizeDp();
        int sizePx = dpToPx(buttonSizeDp);

        int layoutType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
                sizePx, sizePx,
                layoutType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        params.x = AppPrefs.getPosX(this);
        params.y = AppPrefs.getPosY(this);

        // Set opacity
        float alpha = AppPrefs.getOpacity(this) / 100f;
        floatingView.setAlpha(alpha);

        setupGestureDetector();
        setupTouchListener();

        windowManager.addView(floatingView, params);
        AppPrefs.setServiceRunning(this, true);
    }

    private int getButtonSizeDp() {
        // Map 0-100 slider to 40-90 dp
        int progress = AppPrefs.getSize(this);
        return 40 + (int)(progress * 0.5f);
    }

    private void setupGestureDetector() {
        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            private static final int SWIPE_MIN_DISTANCE = 40;
            private static final int SWIPE_MIN_VELOCITY = 100;

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2,
                                   float velocityX, float velocityY) {
                if (e1 == null || e2 == null) return false;
                float dx = e2.getRawX() - e1.getRawX();
                float dy = e2.getRawY() - e1.getRawY();

                boolean isHorizontal = Math.abs(dx) > Math.abs(dy);
                if (isHorizontal && Math.abs(dx) > SWIPE_MIN_DISTANCE
                        && Math.abs(velocityX) > SWIPE_MIN_VELOCITY) {
                    if (dx > 0) {
                        executeAction(AppPrefs.getGesture(FloatingButtonService.this, AppPrefs.KEY_SWIPE_RIGHT));
                    } else {
                        executeAction(AppPrefs.getGesture(FloatingButtonService.this, AppPrefs.KEY_SWIPE_LEFT));
                    }
                    return true;
                } else if (!isHorizontal && Math.abs(dy) > SWIPE_MIN_DISTANCE
                        && Math.abs(velocityY) > SWIPE_MIN_VELOCITY) {
                    if (dy > 0) {
                        executeAction(AppPrefs.getGesture(FloatingButtonService.this, AppPrefs.KEY_SWIPE_DOWN));
                    } else {
                        executeAction(AppPrefs.getGesture(FloatingButtonService.this, AppPrefs.KEY_SWIPE_UP));
                    }
                    return true;
                }
                return false;
            }
        });
    }

    private void setupTouchListener() {
        floatingView.setOnTouchListener((v, event) -> {
            gestureDetector.onTouchEvent(event);

            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    isDragging = false;
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float movedX = Math.abs(event.getRawX() - initialTouchX);
                    float movedY = Math.abs(event.getRawY() - initialTouchY);
                    if (movedX > DRAG_THRESHOLD || movedY > DRAG_THRESHOLD) {
                        isDragging = true;
                    }
                    if (isDragging && !AppPrefs.isLockPosition(this)) {
                        params.x = initialX + (int)(event.getRawX() - initialTouchX);
                        params.y = initialY + (int)(event.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    if (isDragging) {
                        // Save new position
                        AppPrefs.setPos(this, params.x, params.y);
                    } else {
                        // It's a tap - check for double tap
                        long now = System.currentTimeMillis();
                        if (now - lastTapTime < DOUBLE_TAP_WINDOW) {
                            // Double tap
                            lastTapTime = 0;
                            vibrate(30);
                            executeAction(AppPrefs.getGesture(this, AppPrefs.KEY_DOUBLE_TAP));
                        } else {
                            lastTapTime = now;
                            vibrate(15);
                            // Delay single tap to allow double tap detection
                            floatingView.postDelayed(() -> {
                                if (System.currentTimeMillis() - lastTapTime >= DOUBLE_TAP_WINDOW - 10) {
                                    executeAction(AppPrefs.getGesture(FloatingButtonService.this,
                                            AppPrefs.KEY_SINGLE_TAP));
                                }
                            }, DOUBLE_TAP_WINDOW);
                        }
                    }
                    return true;
            }
            return false;
        });
    }

    private void executeAction(String action) {
        vibrate(20);
        NavAccessibilityService.performAction(action);
    }

    private void vibrate(int ms) {
        if (!AppPrefs.isVibration(this) || vibrator == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            vibrator.vibrate(ms);
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return (int)(dp * density);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null && windowManager != null) {
            windowManager.removeView(floatingView);
        }
        AppPrefs.setServiceRunning(this, false);
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, FloatingButtonService.class);
        stopIntent.setAction("STOP");
        PendingIntent stopPending = PendingIntent.getService(this, 0, stopIntent,
                PendingIntent.FLAG_IMMUTABLE);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("TouchNav Aktif")
                .setContentText("Yüzen navigasyon düğmesi çalışıyor")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(openPending)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Durdur", stopPending)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
        }
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "TouchNav Servisi",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Yüzen navigasyon düğmesi servisi");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }
}
